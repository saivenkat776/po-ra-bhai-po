package Service;

import Bean.AccountBean;
import Bean.ProfileBean;
import Dao.AccountDao;
import Dao.ProfileDao;

public class AccountCreationService {

	public static Long addAccountService(String name, String street, String city, String state, int zip,
			String business, String uname) {
		// TODO Auto-generated method stub
		AccountDao AccountDao = new AccountDao();
		AccountBean accbean = new AccountBean();
		accbean.setName(name);
		accbean.setStreet(street);
		accbean.setCity(city);
		accbean.setState(state);
		accbean.setZip(zip);
		accbean.setBusiness(business);
		accbean.setUname(uname);

		long Accseq = 0;
		 try
		 {
			 Accseq = AccountDao.addAccount(accbean);
			 return Accseq;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return Accseq;
		 }
	}

}
