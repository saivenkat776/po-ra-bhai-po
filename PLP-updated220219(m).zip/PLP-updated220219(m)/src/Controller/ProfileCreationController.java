package Controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Service.ProfileCreationService;

public class ProfileCreationController extends HttpServlet{
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		RequestDispatcher rd = null;
		String user="";
		String pass="";
		String role="";
		
		user=request.getParameter("userid");
		pass=request.getParameter("pass");
		role=request.getParameter("role");
		
		int updateCount = ProfileCreationService.addprofileService(user, pass, role);
		System.out.println("inserted "+updateCount+" record   Success");
		
		if (updateCount==1) {
			rd = request.getRequestDispatcher("/admin.jsp");
			
		} else {
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
}
}
