package Service;

import java.util.HashMap;

import Dao.AgentInsertPolicyDao;
import Dao.AgentPolicyInsertDao;
import Dao.AgentPremiumCalDao;

public class AgentPremiumCalService {

	public int CalculatePremium(HashMap<String, String> ans,long acc) {
		// TODO Auto-generated method stub
		AgentPremiumCalDao predao=new AgentPremiumCalDao();
		int res=predao.CalDao(ans); 
		
	AgentPolicyInsertDao polins=new AgentPolicyInsertDao();
	 
		int res1=polins.PolIns(res,acc);
		return res1;
		
	}

	public int Inspol(int policynumber, HashMap<String, String> ans) {
		// TODO Auto-generated method stub
		AgentInsertPolicyDao insdao=new AgentInsertPolicyDao();
		int k=insdao.Inspol(policynumber,ans);
		return k;
	}


}
