package Service;

import Bean.AccountBean;
import Bean.ProfileBean;
import Dao.AccountDao;
import Dao.ProfileDao;

public class AccountCreationService {

	public static int addAccountService(String name, String street, String city, String state, int zip,
			String business, String uname) {
		// TODO Auto-generated method stub
		AccountDao AccountDao = new AccountDao();
		AccountBean accbean = new AccountBean();
		accbean.setName(name);
		accbean.setStreet(street);
		accbean.setCity(city);
		accbean.setState(state);
		accbean.setZip(zip);
		accbean.setBusiness(business);
		accbean.setUname(uname);

		int updateResult = 0;
		 try
		 {
			 updateResult = AccountDao.addAccount(accbean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	}

}
