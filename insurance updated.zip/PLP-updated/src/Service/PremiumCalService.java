package Service;

import java.util.HashMap;

import Dao.PolicyInsertDao;
import Dao.PremiumCalDao;

public class PremiumCalService {

	public int CalculatePremium(HashMap<String, String> ans) {
		// TODO Auto-generated method stub
		PremiumCalDao predao=new PremiumCalDao();
		int res=predao.CalDao(ans); 
		
	PolicyInsertDao polins=new PolicyInsertDao();
		int res1=polins.PolIns(res);
		return res1;
		
	}


}
