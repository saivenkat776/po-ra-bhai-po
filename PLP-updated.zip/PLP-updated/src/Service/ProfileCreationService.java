package Service;

import Bean.ProfileBean;
import Dao.ProfileDao;


public class ProfileCreationService {

	public static int addprofileService(String user, String pass, String role) {
		// TODO Auto-generated method stub
		ProfileDao ProfileDao = new ProfileDao();
		ProfileBean probean = new ProfileBean();
		probean.setUser(user);
		probean.setPass(pass);
		probean.setRole(role);

		int updateResult = 0;
		 try
		 {
			 updateResult = ProfileDao.addProfile(probean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	}

}
